<?php
    include_once('../config.php');
    if(isset($_POST['update']))
    {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $sexo = $_POST['sexo'];
    $data_nasc = $_POST['data_nascimento'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $endereco = $_POST['endereco'];
    $cargos = $_POST['cargos'];
    $atendimento = $_POST['atendimento'];
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];
        
        $sqlUpdate = mysqli_query($conexao, "UPDATE funcionarios
        SET nome='$nome',email='$email',telefone='$telefone',sexo='$sexo',
        data_nascimento='$data_nascimento',cidade='$cidade',estado='$estado',
        endereco='$endereco', cargos='$cargos', atendimento='$atendimento', usuario='$usuario', senha='$senha'
        WHERE id= '$id'");
        $result = $conexao->query($sqlUpdate);
    }
    header('Location: /posto/estoque/funcionario.php');
?>
