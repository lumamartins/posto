<?php

// SISTEMA onde está salvo os dados cadastrais dos pacientes
ini_set('default_charset', 'utf-8');
    session_start();
    include_once('../../config.php');
    // print_r($_SESSION);
    if((!isset($_SESSION['usuario']) == true) and (!isset($_SESSION['senha']) == true))
    {
        unset($_SESSION['usuario']);
        unset($_SESSION['senha']);
        header('Location: ./acoes/login.php');
    }
    // usuário logado (funcionário) no sistema
    $logado = $_SESSION['usuario'];
    if(!empty($_GET['search']))
    {
        $data = $_GET['search'];
        $sql = "SELECT * FROM pacientes WHERE id LIKE '%$data%' or nome LIKE '%$data%' or cpf LIKE '%$data%' ORDER BY id DESC";
    }
    else
    {
        $sql = "SELECT * FROM pacientes ORDER BY id DESC";
    }
    $result = $conexao->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Ficha dos Pacientes | Posto Fácil</title>
    <style>
        body{
            background-image:"back_sistema.jpg";
            background-size: cover;
            color: white;
            text-align: center;
        }

        .navbar{
    display: flex;
    justify-content: space-between;
    align-items:center;
    background-color: white;
    padding: 15px 30px;
    
    margin: 0;
    padding: 0;
    top: 0;
    width:100%;
    
   
}
.logo img{
    width: 200px;
    margin-left: 30%;
   
}
        .table-bg{
            background: #74B5DB;
            border-radius: 15px 15px 0 0;
        }

        .box-search{
            display: flex;
            justify-content: center;
            gap: .1%;
        }
        h1{
            color:#74B5DB;
        }

        .login-button {
    
    display: flex;
    align-items: center;
    justify-content: end;
    margin-right: 2rem;
    
    
    
}

.login-button button {
    border: none;
    background-color: #A1C7E0;
    padding: 0.4rem 1rem;
    border-radius: 5px;
    cursor: pointer;
}

.login-button button:hover {
    background-color: #0099DD;
}

.login-button button a {
    text-decoration: none;
    font-weight: 500;
    color: #fff;
}
    </style>
</head>
<body>
<nav class="navbar" >
    <div class="logo" >
<img src="/posto/imagens/POSTO FÁCIL.png"  width="444px" alt="">

    </div>
        <div class="container-fluid">
            <a class="navbar-brand" href="#" img src="postofacil_logo.png"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    
    </nav>
    <br>
    <?php
        echo "<h1>Bem vindo <u>$logado</u></h1>";
    ?>
    <div class="login-button">
                        <button><a href="/posto/acoes/sistemas/sistema.php">Voltar</a></button>
                    </div>
    <br>
    <div class="box-search">
        <input type="search" class="form-control w-25" placeholder="Digite o id, nome ou cpf do paciente" id="pesquisar">
        <button onclick="searchData()" class="btn btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
        </button>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <div class="m-5">
        <table class="table text-white table-bg">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">CPF</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Idade</th>
                    <th scope="col">RG</th>
                    <th scope="col">Sexo</th>
                    <th scope="col">Telefone</th>
                    <th scope="col">Data de Nascimento</th>
                    <th scope="col">Cidade</th>
                    <th scope="col">Estado</th>
                    <th scope="col">CEP</th>
                    <th scope="col">Endereço</th>
                    <th scope="col">Alergia</th>
                    <th scope="col">Descrição:</th>
                    <th scope="col">...</th>
                    <th scope="col">...</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    while($user_data = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>".$user_data['id']."</td>";
                        echo "<td>".$user_data['cpf']."</td>";
                        echo "<td>".$user_data['nome']."</td>";
                        echo "<td>".$user_data['idade']."</td>";
                        echo "<td>".$user_data['rg']."</td>";
                        echo "<td>".$user_data['sexo']."</td>";
                        echo "<td>".$user_data['telefone']."</td>";
                        echo "<td>".$user_data['data_nascimento']."</td>";
                        echo "<td>".$user_data['cidade']."</td>";
                        echo "<td>".$user_data['estado']."</td>";
                        echo "<td>".$user_data['cep']."</td>";
                        echo "<td>".$user_data['endereco']."</td>";
                        echo "<td>".$user_data['alergia']."</td>";
                        echo "<td>".$user_data['descricao_alergia']."</td>";

                        echo "<td>
                        <a class='btn btn-sm btn-primary' href='/posto/acoes/edit_pacientes.php?id=$user_data[id]' title='Editar'>
                            <svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='currentColor' class='bi bi-pencil' viewBox='0 0 16 16'>
                                <path d='M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z'/>
                            </svg>
                            <br>
                            </a> 
                            <a class='btn btn-sm ' href='/posto/acoes/delete_pacientes.php?id=$user_data[id]' title='Deletar'>
                            <svg xmlns='http://www.w3.org/2000/svg' width='25' height='25' viewBox='0 0 96 96'>
                            <path fill='#4d4dff' d='M63.149,83H32.82c-3.308,0-7.411-1.293-8.176-7.453c-0.005-0.045-0.01-0.09-0.014-0.135	l-3.622-46.178c-0.129-1.651,1.104-3.096,2.757-3.226c1.651-0.118,3.096,1.105,3.226,2.757l3.616,46.106	C30.854,76.789,31.282,77,32.82,77h30.329c1.882,0,1.972,0,2.263-2.363l3.597-45.871c0.13-1.651,1.551-2.894,3.226-2.757	c1.652,0.13,2.886,1.574,2.757,3.226l-3.603,45.937c-0.004,0.044-0.008,0.087-0.014,0.131C71.093,77.605,70.432,83,63.149,83z' opacity='.3'></path><path fill='#4d4dff' d='M63.149,82H32.82c-4.225,0-6.642-2.213-7.183-6.576l-3.632-46.268	c-0.086-1.101,0.736-2.063,1.838-2.15c1.104-0.092,2.064,0.737,2.15,1.838l3.622,46.178C29.898,77.283,30.649,78,32.82,78h30.329	c2.594,0,2.935-0.627,3.263-3.307l3.594-45.85c0.086-1.102,1.067-1.91,2.15-1.838c1.102,0.087,1.924,1.05,1.838,2.15l-3.603,45.937	C69.948,78.722,68.771,82,63.149,82z' opacity='.3'></path><path fill='#0fd2ff' d='M75,27H21c-1.657,0-3-1.343-3-3s1.343-3,3-3h54c1.657,0,3,1.343,3,3S76.657,27,75,27z' opacity='.3'></path><path fill='#0fd2ff' d='M75,26H21c-1.104,0-2-0.896-2-2s0.896-2,2-2h54c1.104,0,2,0.896,2,2S76.104,26,75,26z' opacity='.3'></path><path fill='#0fd2ff' d='M37.998,66c-1.598,0-2.925-1.259-2.995-2.87l-1-23c-0.072-1.655,1.212-3.055,2.867-3.127	c1.633-0.086,3.055,1.211,3.127,2.867l1,23c0.072,1.655-1.212,3.055-2.867,3.127C38.086,65.999,38.042,66,37.998,66z' opacity='.3'></path><path fill='#0fd2ff' d='M37.998,65c-1.064,0-1.949-0.839-1.996-1.913l-1-23	c-0.048-1.104,0.808-2.037,1.911-2.085c1.095-0.018,2.037,0.808,2.085,1.911l1,23c0.048,1.104-0.808,2.037-1.911,2.085	C38.058,64.999,38.027,65,37.998,65z' opacity='.3'></path><path fill='#0fd2ff' d='M58.002,66c-0.044,0-0.088-0.001-0.132-0.003c-1.655-0.072-2.939-1.472-2.867-3.127l1-23	c0.072-1.656,1.493-2.941,3.127-2.867c1.655,0.072,2.939,1.472,2.867,3.127l-1,23C60.927,64.741,59.599,66,58.002,66z' opacity='.3'></path><path fill='#0fd2ff' d='M58.002,65c-0.03,0-0.06-0.001-0.089-0.002c-1.104-0.048-1.959-0.981-1.911-2.085l1-23	c0.048-1.104,1.02-1.943,2.085-1.911c1.104,0.048,1.959,0.981,1.911,2.085l-1,23C59.951,64.161,59.066,65,58.002,65z' opacity='.3'></path><path fill='#0fd2ff' d='M48,66c-1.657,0-3-1.343-3-3V40c0-1.657,1.343-3,3-3s3,1.343,3,3v23	C51,64.657,49.657,66,48,66z' opacity='.3'></path><path fill='#0fd2ff' d='M48,65c-1.104,0-2-0.896-2-2V40c0-1.104,0.896-2,2-2s2,0.896,2,2v23	C50,64.104,49.104,65,48,65z' opacity='.3'></path><path fill='#0fd2ff' d='M58.003,22c-0.06,0-0.119-0.002-0.179-0.005c-1.654-0.098-2.916-1.518-2.819-3.171	c0.023-0.396-0.011-0.622-0.037-0.729c-0.122-0.041-0.403-0.106-0.918-0.095H42c-0.474,0-0.786,0.038-0.979,0.075	C41,18.347,41,18.722,41,19c0,1.657-1.343,3-3,3s-3-1.343-3-3c0-1.731,0-7,7-7h12c2.277-0.012,4.062,0.611,5.324,1.929	c1.237,1.29,1.8,3.056,1.671,5.247C60.901,20.771,59.579,22,58.003,22z M55.047,18.126L55.047,18.126L55.047,18.126z' opacity='.3'></path><path fill='#0fd2ff' d='M58.002,21c-0.04,0-0.079-0.001-0.119-0.004c-1.103-0.064-1.944-1.011-1.879-2.113	c0.042-0.726-0.061-1.256-0.289-1.494c-0.249-0.261-0.854-0.402-1.682-0.389H42c-2,0-2,0.037-2,2c0,1.104-0.896,2-2,2s-2-0.896-2-2	c0-1.947,0-6,6-6h12c1.999-0.029,3.54,0.513,4.603,1.62c1.037,1.082,1.506,2.595,1.394,4.497C59.935,20.18,59.053,21,58.002,21z' opacity='.3'></path><path fill='#4d4dff' d='M63.149,81H32.82c-3.689,0-5.715-1.864-6.19-5.699l-3.627-46.223	c-0.043-0.551,0.368-1.032,0.919-1.075c0.544-0.04,1.032,0.367,1.075,0.919L28.619,75.1c0.353,2.831,1.492,3.9,4.201,3.9h30.329	c3.389,0,3.898-1.275,4.256-4.186l3.598-45.893c0.043-0.552,0.531-0.958,1.075-0.919c0.551,0.043,0.962,0.524,0.919,1.075	l-3.603,45.937C69.021,78.064,68.236,81,63.149,81z'></path><path fill='#0fd2ff' d='M75,25H21c-0.553,0-1-0.447-1-1s0.447-1,1-1h54c0.553,0,1,0.447,1,1S75.553,25,75,25z'></path><path fill='#0fd2ff' d='M37.999,64c-0.532,0-0.975-0.42-0.998-0.957l-1-23c-0.024-0.552,0.404-1.018,0.956-1.042	c0.559-0.032,1.018,0.404,1.042,0.956l1,23c0.024,0.552-0.404,1.018-0.956,1.042C38.028,64,38.014,64,37.999,64z'></path><path fill='#0fd2ff' d='M58.001,64c-0.015,0-0.029,0-0.044-0.001c-0.552-0.024-0.98-0.49-0.956-1.042l1-23	c0.024-0.552,0.498-0.986,1.042-0.956c0.552,0.024,0.98,0.49,0.956,1.042l-1,23C58.976,63.58,58.533,64,58.001,64z'></path><path fill='#0fd2ff' d='M48,64c-0.553,0-1-0.447-1-1V40c0-0.553,0.447-1,1-1s1,0.447,1,1v23C49,63.553,48.553,64,48,64z'></path><path fill='#0fd2ff' d='M58.001,20c-0.02,0-0.04-0.001-0.06-0.002c-0.552-0.032-0.972-0.506-0.939-1.057	c0.061-1.035-0.13-1.79-0.565-2.245c-0.461-0.481-1.294-0.714-2.42-0.696H42c-3,0-3,1.003-3,3c0,0.553-0.447,1-1,1s-1-0.447-1-1	c0-1.991,0-5,5-5h12c1.722-0.028,3.019,0.414,3.881,1.313c0.836,0.872,1.212,2.133,1.117,3.746C58.967,19.59,58.526,20,58.001,20z'></path>
                            </svg>
                                <br>
                            </a>
                            <a class='btn btn-sm' href='http://api.whatsapp.com/send?1=pt_BR&amp;telefone=$user_data[telefone]' title='WhatsApp'>
                            <svg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 40 40'>
                            <path fill='#fff' d='M4.221,29.298l-0.104-0.181c-1.608-2.786-2.459-5.969-2.458-9.205 C1.663,9.76,9.926,1.5,20.078,1.5c4.926,0.002,9.553,1.919,13.03,5.399c3.477,3.48,5.392,8.107,5.392,13.028 c-0.005,10.153-8.268,18.414-18.42,18.414c-3.082-0.002-6.126-0.776-8.811-2.24l-0.174-0.096l-9.385,2.46L4.221,29.298z'></path><path fill='#4788c7' d='M20.078,2L20.078,2c4.791,0.001,9.293,1.867,12.676,5.253C36.137,10.639,38,15.14,38,19.927 c-0.005,9.878-8.043,17.914-17.927,17.914c-2.991-0.001-5.952-0.755-8.564-2.18l-0.349-0.19l-0.384,0.101l-8.354,2.19 l2.226-8.131l0.11-0.403L4.55,28.867c-1.566-2.711-2.393-5.808-2.391-8.955C2.163,10.036,10.202,2,20.078,2 M20.078,1 C9.651,1,1.163,9.485,1.158,19.912c-0.002,3.333,0.869,6.588,2.525,9.455L1,39.169l10.03-2.63c2.763,1.507,5.875,2.3,9.042,2.302 h0.008c10.427,0,18.915-8.485,18.92-18.914c0-5.054-1.966-9.807-5.538-13.382C29.89,2.971,25.14,1.002,20.078,1L20.078,1z'></path><path fill='#98ccfd' d='M19.995,35c-2.504-0.001-4.982-0.632-7.166-1.823l-1.433-0.782l-1.579,0.414l-3.241,0.85l0.83-3.03 l0.453-1.656L7,27.485c-1.309-2.267-2.001-4.858-2-7.492C5.004,11.726,11.732,5.001,19.998,5c4.011,0.001,7.779,1.563,10.61,4.397 C33.441,12.231,35,15.999,35,20.005C34.996,28.273,28.268,35,19.995,35z'></path><path fill='#fff' d='M28.085,24.186c-0.443-0.221-2.621-1.293-3.026-1.44c-0.406-0.148-0.702-0.221-0.997,0.221 c-0.295,0.443-1.144,1.44-1.402,1.735c-0.258,0.295-0.516,0.332-0.96,0.111s-1.87-0.69-3.561-2.198 c-1.317-1.173-2.206-2.624-2.464-3.067s-0.028-0.682,0.194-0.903c0.199-0.199,0.443-0.518,0.664-0.776 c0.221-0.258,0.295-0.443,0.443-0.739c0.148-0.295,0.074-0.555-0.037-0.776c-0.111-0.221-0.997-2.401-1.366-3.287 c-0.359-0.863-0.725-0.746-0.997-0.759c-0.258-0.013-0.553-0.015-0.848-0.015c-0.295,0-0.776,0.111-1.181,0.555S11,14.363,11,16.542 s1.587,4.285,1.808,4.58c0.221,0.295,3.122,4.767,7.566,6.685c1.056,0.455,1.882,0.728,2.524,0.933 c1.061,0.337,2.026,0.289,2.79,0.175c0.851-0.128,2.621-1.071,2.989-2.105c0.369-1.034,0.369-1.921,0.258-2.105 C28.824,24.519,28.529,24.407,28.085,24.186z'></path>
                            </svg>
                        </a>
                        <a class='btn btn-sm' href='/posto/acoes/sistemas/gerar_pdf.php?id=$user_data[id]' title='Gerar Pdf'>
                        <svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='currentColor' class='bi bi-chat-left-text' viewBox='0 0 16 16'>
                    <path d='M14 1a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H4.414A2 2 0 0 0 3 11.586l-2 2V2a1 1 0 0 1 1-1zM2 0a2 2 0 0 0-2 2v12.793a.5.5 0 0 0 .854.353l2.853-2.853A1 1 0 0 1 4.414 12H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z'/>
                    <path d='M3 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5M3 6a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 6m0 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5'/>
                  </svg>
                </a>
                            </td>";
                        echo "</tr>";
                    
                    }
                    ?>
            </tbody>
        </table>
    </div>
</body>
<script>
    var search = document.getElementById('pesquisar');

    search.addEventListener("keydown", function(event) {
        if (event.key === "Enter") 
        {
            searchData();
        }
    });

    function searchData()
    {
        window.location = 'sistema_paciente.php?search='+search.value;
    }
</script>

<script>
        function gerarPDF(id) {
            // Obtenha os dados do paciente com base no ID (usando AJAX)
            // e, em seguida, chame a função para gerar o PDF
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var dadosPaciente = JSON.parse(xhr.responseText);
                    gerarPDFInternamente(dadosPaciente);
                }
            };

            xhr.open('GET', 'obter_dados_paciente.php?id=' + idPaciente, true);
            xhr.send();
        }

        function gerarPDFInternamente(dadosPaciente) {
            // Crie um novo objeto jsPDF
            var pdf = new jsPDF();

            // Adicione as informações do paciente ao PDF
            pdf.text('ID: ' + dadosPaciente.id, 20, 20);
            pdf.text('Nome: ' + dadosPaciente.nome, 20, 30);
            pdf.text('Data de Nascimento: ' + dadosPaciente.data_nascimento, 20, 40);

            // Salve o PDF ou abra em uma nova janela
            pdf.save('dados_paciente.pdf');
        }
    </script>
</html>