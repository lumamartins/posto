<?php

ini_set('default_charset', 'utf-8'); 
    include_once('../../config.php');
    require ('../receita/fpdf.php');

    if(!empty($_GET['id']))
    {
        $id = $_GET['id'];
        $sqlSelect = "SELECT * FROM pacientes WHERE id=$id";
        $result = $conexao->query($sqlSelect);
        if($result->num_rows > 0)
        {
            while($user_data = mysqli_fetch_assoc($result))
            {
                 $cpf = $user_data['cpf'];
                $nome = $user_data['nome'];
                $idade = $user_data['idade'];
                $rg = $user_data['rg'];
                $sexo = $user_data['sexo'];
                $telefone = $user_data['telefone'];
                $data_nascimento = $user_data['data_nascimento'];
                $cidade = $user_data['cidade'];
                $estado = $user_data['estado'];
                $endereco = $user_data['endereco'];
                $alergia = $user_data['alergia'];
                $descricao_alergia = $user_data['descricao_alergia'];  
        } 
    }
        else
        {
            header('Location: ../sistemas/sistema_paciente.php');
        }
    }
   
    $pdf = new FPDF();
       $pdf->AddPage();
       $pdf->SetFont('Arial', 'B', 16);
       $pdf->Ln(10);
       $pdf->SetFont('Arial', '', 12);
       $pdf->Cell(0, 10, "CPF: $cpf", 0, 1);
       $pdf->Cell(0, 10, "Paciente: $nome", 0, 1);
       $pdf->Cell(0, 10, "Idade: $idade", 0, 1);
       $pdf->Cell(0, 10, "RG: $rg", 0, 1);
       $pdf->Cell(0, 10, "Sexo: $sexo", 0, 1);
       $pdf->Cell(0, 10, "Telefone: $telefone", 0, 1);
       $pdf->Cell(0, 10, "Data Nascimento: $data_nascimento", 0, 1);
       $pdf->Cell(0, 10, "Cidade: $cidade", 0, 1);
       $pdf->Cell(0, 10, "Estado: $estado", 0, 1);
       $pdf->Cell(0, 10, "Endereço: $endereco", 0, 1);
       $pdf->Cell(0, 10, "Alergia: $alergia", 0, 1);
       $pdf->Cell(0, 10, "Descrição da alergia: $descricao_alergia", 0, 1);
       $filename = 'dadospaciente.pdf';
       $pdf->Output('D', $filename);


       

?>

