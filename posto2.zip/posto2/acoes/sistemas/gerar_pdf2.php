<?php

ini_set('default_charset', 'utf-8'); 
    include_once('../../config.php');
    require ('../receita/fpdf.php');

    if(!empty($_GET['id']))
    {
        $id = $_GET['id'];
        $sqlSelect = "SELECT * FROM receita WHERE id=$id";
        $result = $conexao->query($sqlSelect);
        if($result->num_rows > 0)
        {
            while($user_data = mysqli_fetch_assoc($result))
            {
        
                $cpf = $user_data['cpf'];
                $nome = $user_data['nome'];
                $data_nascimento = $user_data['data_nascimento'];
                $idade = $user_data['idade'];
                $funcionario = $user_data['funcionario'];
                $dt = $user_data['dt'];
                $medicamento = $user_data['medicamento'];
                $dosagem = $user_data['dosagem'];
                $instrucoes= $user_data['instrucoes'];
    }
}
        else
        {
            header('Location: ../acoes/receita/receitamedica.php');
        }
    }
   
    $pdf = new FPDF();
       $pdf->AddPage();
       $pdf->SetFont('Arial', 'B', 16);
       $pdf->Ln(10);
       $pdf->SetFont('Arial', '', 12);
       $pdf->Cell(0, 10, "Cpf: $cpf", 0, 1);
       $pdf->Cell(0, 10, "Nome: $nome", 0, 1);
       $pdf->Cell(0, 10, "Data de Nascimento: $data_nascimento", 0, 1);
       $pdf->Cell(0, 10, "Idade: $idade", 0, 1);
       $pdf->Cell(0, 10, "Funcionário: $funcionario", 0, 1);
       $pdf->Cell(0, 10, "Data: $dt", 0, 1);
       $pdf->Cell(0, 10, "Medicamento prescrito: $medicamento", 0, 1);
       $pdf->Cell(0, 10, "Dosagem: $dosagem", 0, 1);
       $pdf->Cell(0, 10, "Instruções: $instrucoes", 0, 1);
       $filename = 'nome.pdf';
       $pdf->Output('D', $filename);

?>

