<?php
// Pagina para deletar as informações das vacinas cadastradas
ini_set('default_charset', 'utf-8'); 
    if(!empty($_GET['id']))
    {
        include_once('../config.php');
        $id = $_GET['id'];
        $sqlSelect = "SELECT *  FROM vacina_paciente WHERE id=$id";
        $result = $conexao->query($sqlSelect);

        if($result->num_rows > 0)
        {
            $sqlDelete = "DELETE FROM vacina_paciente WHERE id=$id";
            $resultDelete = $conexao->query($sqlDelete);
        }
    }
    header('Location: ../estoque/historico_vac_paciente.php');
   
?>
