<?php
// Salvamento da edição da vacinação do paciente

    include_once('../config.php');
    if(isset($_POST['update']))
    {
        $id = $_POST['id'];
        $cpf = $_POST['cpf'];
        $nome = $_POST['nome'];
        $nome_vacina = $_POST['nome_vacina'];
        $data_vacinacao = $_POST['data_vacinacao'];
        
        $sqlUpdate = mysqli_query($conexao, "UPDATE vacina_paciente
        SET cpf='$cpf',nome='$nome',nome_vacina='$nome_vacina',lote='$lote',data_vacinacao='$data_vacinacao'
        WHERE id= '$id'");
        $result = $conexao->query($sqlUpdate);
    }
    header('Location: /posto/estoque/historico_vac_paciente.php');
?>
