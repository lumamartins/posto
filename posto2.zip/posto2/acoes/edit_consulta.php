<?php

// pagina para editar as informações da consulta cadastrada no sistema
ini_set('default_charset', 'utf-8'); 
    include_once('../config.php');

    if(!empty($_GET['id']))
    {
        $id = $_GET['id'];
        $sqlSelect = "SELECT * FROM consulta WHERE id=$id";
        $result = $conexao->query($sqlSelect);
        if($result->num_rows > 0)
        {
            while($user_data = mysqli_fetch_assoc($result))
            {
                $nome = $user_data['nome'];   
                $dataconsulta = $user_data['dataconsulta'];   
                $hora = $user_data['hora'];   
                $motivo = $user_data['motivo'];  
        } 
    }
        else
        {
            header('Location: ../consulta_medica/consulta_view.php');
        }
    }
 
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Tela de Consulta Médica</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500&family=Open+Sans:wght@300;400;500;600&display=swap');
  body {
    background-image: url(/imagens/maos-da-medica-irreconhecivel-escrevendo-no-formulario-e-digitando-no-teclado-do-laptop.jpg);
    background-size: cover;
  background-position: center;
  font-family: 'Inter', sns-serif;
    background-color: #f7f7f7;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  
  .container {
    
    max-width: 600px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 0 10px black;
    padding: 40px;
  }
  .form-group {
    margin-bottom: 20px;
  }
  .form-control {
    width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 16px;
  transition: border-color 0.3s;
  }

  .form-control:focus {
  border-color: #007bff;
}
  label {
    font-weight: bold;
 
  }

  
  
  button {
    padding: 12px 24px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;
  }
  button:hover {
  background-color: #0056b3;
}
  .appointments {
    margin-top: 30px;
    border-top: 1px solid #ccc;
    padding-top: 20px;
  }

  h1{
    font-weight: 500;
  }
  h2 {
    
    font-size: 24px;
    margin-bottom: 10px;
  }
  ul {
    list-style-type: none;
    padding: 0;
  }
  li {
    margin-bottom: 10px;
    font-size: 16px;
  }
</style>
</head>
<body>
  <form action="saveEdit4.php" method="POST">
  <div class="container">
    <h1 style="text-align: center; color: #007bff; margin-bottom: 3.5rem;">Editar Consulta Médica</h1>
    <div class="form-group">
      <label  for="nome">Nome do Paciente:</label>
      <input type="text" id="nome" class="form-control" name="nome" value="<?php echo $nome ?>" required>
    </div>
    <div class="form-group">
      <label for="dataconsulta">Data da Consulta:</label>
      <input type="date" id="dataconsulta" class="form-control" name="dataconsulta"  value="<?php echo $dataconsulta ?>" required>
    </div>
    <div class="form-group">
      <label for="hora">Horário:</label>
      <input type="time" id="hora" class="form-control" name="hora" value="<?php echo $hora ?>" required>
    </div>
    <div class="form-group">
      <label for="motivo">Motivo da Consulta:</label>
      <textarea id="motivo" class="form-control" rows="4" name="motivo" required><?php echo $motivo ?></textarea>

    </div>
    <input type="hidden" name="id" value="<?php echo $id?>">
    <input type="submit" name="update" id="update">
  </form>

  </div>
</body>
</html>