<?php

// pagina para editar as informações do funcionario cadastrado no sistema
ini_set('default_charset', 'utf-8'); 
    include_once('../config.php');

    if(!empty($_GET['id']))
    {
        $id = $_GET['id'];
        $sqlSelect = "SELECT * FROM funcionarios WHERE id=$id";
        $result = $conexao->query($sqlSelect);
        if($result->num_rows > 0)
        {
            while($user_data = mysqli_fetch_assoc($result))
            { $nome = $user_data['nome'];
                $email = $user_data['email'];
                $telefone = $user_data['telefone'];
                $sexo = $user_data['sexo'];
                $data_nascimento = $user_data['data_nascimento'];
                $cidade = $user_data['cidade'];
                $estado = $user_data['estado'];
                $endereco = $user_data['endereco'];
                $cargos = $user_data['cargos'];
                $atendimento = $user_data['atendimento'];
                $usuario = $user_data['usuario'];
                $senha = $user_data['senha'];
            }
        }
        else
        {
            header('Location: ../estoque/funcionario.php');
        }
      }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

  

  <style>


*{
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: "Poppins", sans-serif;
  
}

body{
  
  background: #ccedff;
  width: 100%;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.container{
  background-color: #fafafa;
  border-radius: 14px;
  margin: 14px;
  max-width: 600px;
  width: 100%;
  box-sizing: 0 3px 5px rgba(0,0,0, 0.5);
  overflow: hidden;
}
.container2{
  background-color: #fafafa;
  border-radius: 14px;
  margin: 14px;
  max-width: 600px;
  width: 100%;
  box-sizing: 0 3px 5px rgba(0,0,0, 0.5);
  overflow: hidden;

}

.header{
  background: linear-gradient(120deg, #3acbf0 0%, #8bb0ff 100%);
  padding: 24px;
  text-align: center;
  color: #FFF;
}

.form{
  padding: 18px;
}

.form-content{
  margin-bottom: 8px;
  padding-bottom: 18px;
  position: relative;
}

.form-content label{
  display: inline-block;
  margin-bottom: 4px;
}

.form-content input{
  display: block;
  width: 100%;
  border-radius: 8px;
  padding: 8px;
  border: 2px solid #dfdfdf;
}

.form-content a{
  position: absolute;
  bottom: -8px;
  left: 0;
  visibility: hidden;
}

.form button{
  background-color: #00c3ff;
  color: #FFF;
  width: 100%;
  border-radius: 14px;
  padding: 10px;
  border: 0;
  font-size: 16px;
  cursor: pointer;
  margin-top: 14px;
}

.form-content.error input{
  border-color: #ff3b25;
}

.form-content.error a{
  color: #ff3b25;
  visibility: visible;
}
#sexo{
  display: flex;
  flex-direction: column;

}

form-content label {
  display: flex;
  align-items: center;
}

/* Estilize os inputs do tipo radio */
.form-content input[type="radio"] {
  appearance: none; 
  -webkit-appearance: none;
  -moz-appearance: none;
  width: 16px; 
  height: 16px; 
  border: 2px solid #333; 
  border-radius: 50%; 
  background-color: white; 
  margin-right: 5px; 
  margin: 3px;
  display: flex;
}


.form-content input[type="radio"]:checked {
  background-color: #333; 
}


.form-content {
  margin-bottom: 10px; 
}


  </style>

  <title>Posto Fácil - Cadastro do Funcionário</title>
</head>
<body>

  <div class="container">
    <section class="header">
      <h2>Cadastro do Funcionário</h2>
    </section>

    <form action="saveEdit7.php" id="form" class="form" method="POST">
      
      <div class="form-content">
        <label for="nome">Nome</label>
        <input
          type="text"
          id="nome"
          name="nome"
          placeholder="Digite seu nome..."
          value="<?php echo $nome ?>" required>
        
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="email">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="Digite seu email..."
          value="<?php echo $email ?>" required>
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="tel">Telefone</label>
        <input
          type="text"
          id="telefone"
          name="telefone"
          placeholder="Digite seu telefone"
          value="<?php echo $telefone?>" required>
        <a>Aqui vai a mensagem de erro....</a>
      </div>
      

      <div  id="sexo"class="form-content">
      <label  for="Sexo"><span>Sexo:</span><br>
          <input  type="radio" id="M" name="sexo" value="M" <?php echo ($sexo =='M') ? 'checked' : '' ?> required > 
          <label for="M">Masculino</label>
          <input  type="radio" id="F" name="sexo" value="F" <?php echo ($sexo =='F') ? 'checked' : '' ?> required> 
          <label for="F">Feminino</label>
          <input  type="radio" id="O"  name="sexo" value="O" <?php echo ($sexo =='O') ? 'checked' : '' ?> required> 
          <label for="O">Outro</label>
        </label>
        
        
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="data_nascimento">Data de Nascimento</label>
        <input
          type="date"
          id="data_nascimento"
          name="data_nascimento"
          value="<?php echo $data_nascimento ?>" required>
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="cidade">Cidade</label>
        <input
          type="text"
          id="cidade"
          name="cidade"
          placeholder="Digite sua cidade"
          value="<?php echo $cidade?>" required>
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="estado">Estado</label>
        <select name="estado" id="estado">
          <option value="">--</option>
          <option value="PR">SP</option>
          <option value="PR">RJ</option>
          <option value="PR">MG</option>
          <option value="PR">PR</option>
          <option value="PR">AC</option>
          <option value="PR">AL</option>
          <option value="PR">AP</option>
          <option value="PR">AM</option>
          <option value="PR">BA</option>
          <option value="PR">CE</option>
      </select>
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="text">Endereço</label>
        <input
          type="text"
          id="endereco"
          name="endereco"
          placeholder="Rua das Flores, 345 - São Pedro"
          value="<?php echo $endereco?>" required>
        <a>Aqui vai a mensagem de erro....</a>
      </div>


<br>

   <div  id="cargos"class="form-content">
        <label  for="atendimento"><span>Cargo:</span><br>
          <input  type="radio" name="cargos" value="Médico" <?php echo ($cargos =='Médico') ? 'checked' : '' ?> required >  Médico</label>
          <input  type="radio" name="cargos" value="Enfermeira"<?php echo ($cargos =='Enfermeira') ? 'checked' : '' ?> required > Enfermagem</label>
          <input  type="radio" name="cargos" value="Administrativo" <?php echo ($cargos =='Admintrador') ? 'checked' : '' ?> required > Administrativo</label>
          <input  type="radio" name="cargos" value="Recepcionista" <?php echo ($cargos =='Recepcionista') ? 'checked' : '' ?> required > Recepcionista</label>
          <input  type="radio" name="cargos" value="Atendente da Farmácia" <?php echo ($cargos =='Atendente da Farmácia') ? 'checked' : '' ?> required >Atendente da Farmácia</label>
          <input  type="radio" name="cargos" value="Dentista" <?php echo ($cargos =='Dentista') ? 'checked' : '' ?> required > Dentista</label>
          <input  type="radio" name="cargos" value="Psicólogo" <?php echo ($cargos =='Psicólogo') ? 'checked' : '' ?> required > Psicólogo</label>
          <input  type="radio" name="cargos" value="Agente da Saúde" <?php echo ($cargos =='Agente da Saúde') ? 'checked' : '' ?> required > Agente da Saúde</label>
        </label>
        <br><br>

   <div  id="sexo"class="form-content">
        <label  for="atendimento"><span>Atendimento:</span><br>
          <input  type="radio" name="atendimento" value="Sim" <?php echo ($atendimento =='Sim') ? 'checked' : '' ?> required > Sim</label>
          <input  type="radio" name="atendimento" value="Não" <?php echo ($atendimento =='Não') ? 'checked' : '' ?> required > Não</label>
        </label>
        
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="usuario">Usúario</label>
        <input
          type="text"
          id="usuario"
          name="usuario"
          placeholder="Digite seu usúario..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="senha">Senha</label>
        <input
          type="password"
          id="senha"
          name="senha"
          placeholder="Digite sua senha..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>
      <input type="hidden" name="id" value="<?php echo $id?>">
    <input type="submit" name="update" id="update">

    </form>

  </div>
  

  
</body>
</html>
