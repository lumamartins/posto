<?php

session_start();
ini_set('default_charset', 'utf-8');
include_once('../config.php');


if(isset($_POST['submit']))
{ 
    $cpf = $_POST['cpf'];
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $rg = $_POST['rg'];
    $sexo = $_POST['sexo'];
    $telefone = $_POST['telefone'];
    $data_nascimento = $_POST['data_nascimento'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $cep = $_POST['cep'];
    $endereco = $_POST['endereco'];
    $alergia = $_POST['alergia'];
    $descricao_alergia = $_POST['descricao_alergia'];

    
        // Colunas referentes a tabela pacientes 
    $result = mysqli_query($conexao, "INSERT INTO pacientes(cpf,nome,idade,rg,sexo,telefone,data_nascimento,cidade,estado,cep,endereco,alergia,descricao_alergia) 
    VALUES('$cpf','$nome','$idade','$rg','$sexo','$telefone','$data_nascimento','$cidade','$estado','$cep','$endereco','$alergia','$descricao_alergia')");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="script.js" type="text/javascript"></script>

  

  <style>


*{
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: "Poppins", sans-serif;
  
}

body{
  
  background: #ccedff;
  width: 100%;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}



.container{
  background-color: #fafafa;
  border-radius: 14px;
  margin: 14px;
  max-width: 600px;
  width: 100%;
  box-sizing: 0 3px 5px rgba(0,0,0, 0.5);
  overflow: hidden;
}
.container2{
  background-color: #fafafa;
  border-radius: 14px;
  margin: 14px;
  max-width: 600px;
  width: 100%;
  box-sizing: 0 3px 5px rgba(0,0,0, 0.5);
  overflow: hidden;

}

.header{
  background: linear-gradient(120deg, #3acbf0 0%, #8bb0ff 100%);
  padding: 24px;
  text-align: center;
  color: #FFF;
}

.login-button {
    
   display: flex;
   position
    align-items: center;
    
    margin-right: 2rem;
    
    
    
}

.login-button button {
    border: none;
    background-color: #A1C7E0;
    padding: 0.4rem 1rem;
    border-radius: 5px;
    cursor: pointer;
}

.login-button button:hover {
    background-color: #0099DD;
}

.login-button button a {
    text-decoration: none;
    font-weight: 500;
    color: #fff;
}

.form{
  padding: 18px;
}

.form-content{
  margin-bottom: 8px;
  padding-bottom: 18px;
  position: relative;
}

.form-content label{
  display: inline-block;
  margin-bottom: 4px;
}

.form-content input{
  display: block;
  width: 100%;
  border-radius: 8px;
  padding: 8px;
  border: 2px solid #dfdfdf;
}

.form-content a{
  position: absolute;
  bottom: -8px;
  left: 0;
  visibility: hidden;
}

.form button{
  background-color: #00c3ff;
  color: #FFF;
  width: 100%;
  border-radius: 14px;
  padding: 10px;
  border: 0;
  font-size: 16px;
  cursor: pointer;
  margin-top: 14px;
}

.form-content.error input{
  border-color: #ff3b25;
}

.form-content.error a{
  color: #ff3b25;
  visibility: visible;
}
#sexo{
  display: flex;
  flex-direction: column;

}

form-content label {
  display: flex;
  align-items: center;
}

/* Estilize os inputs do tipo radio */
.form-content input[type="radio"] {
  appearance: none; 
  -webkit-appearance: none;
  -moz-appearance: none;
  width: 16px; 
  height: 16px; 
  border: 2px solid #333; 
  border-radius: 50%; 
  background-color: white; 
  margin-right: 5px; 
  margin: 3px;
}


.form-content input[type="radio"]:checked {
  background-color: #333; 
}


.form-content {
  margin-bottom: 10px; 
}












  </style>

  <title>cadastro paciente</title>
  
</head>
<body>
<div class="login-button">
                        <button><a href="/posto/acoes/sistemas/sistema.php">Voltar</a></button>
                    </div>

  <div class="container">
    <section class="header">
      <h2>Cadastro do paciente</h2>
    </section>

    <form id="form" class="form" method="POST" onsubmit="return calcularIdade()">
      
      <div class="form-content">
        <label for="cpf">CPF</label>
        <input
          type="CPF"
          id="cpf"
          name="cpf"
          placeholder="Digite o CPF..."
          
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>
      <div class="form-content">
        <label for="nome">Nome</label>
        <input
          type="text"
          id="nome"
          name="nome"
          placeholder="Digite o Nome..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>
    
      <div class="form-content">
        <label for="rg">RG</label>
        <input
          type="text"
          id="rg"
          name="rg"
          placeholder="Digite o RG..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>
  

      <div class="form-content">
        <label for="telefone">Telefone</label>
        <input
          type="text"
          id="telefone"
          name="telefone"
          placeholder="Digite seu telefone"
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div  id="sexo"class="form-content">
        <label  for="Sexo"><span>Sexo:</span><br>
         <input  type="radio" id="sexo" name="sexo" value="M"><label for="M">Masculino</label>
          <input  type="radio" id="sexo" name="sexo" value="F" ><label for="F">Feminino</label>
          <input  type="radio" id="sexo"  name="sexo" value="O" > <label for="O">Outro</label>
        </label>
        
        
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="data_nascimento">Data de Nascimento</label>
        <input
          type="date"
          id="data_nascimento"
          name="data_nascimento"
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="cidade">Cidade</label>
        <input
          type="text"
          id="cidade"
          name="cidade"
          placeholder="Digite sua cidade"
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="estado">Estado</label>
        <select name="estado" id="estado">
          <option value="">--</option>
          <option value="SP">SP</option>
          <option value="RJ">RJ</option>
          <option value="MG">MG</option>
          <option value="ES">ES</option>
          <option value="PR">PR</option>
          <option value="AC">AC</option>
          <option value="AL">AL</option>
          <option value="AP">AP</option>
          <option value="AM">AM</option>
          <option value="BA">BA</option>
          <option value="CE">CE</option>
      </select>
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="cep">CEP</label>
        <input type="text" id="cep" name="cep" placeholder="Digite seu cep...">
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="endereco">Endereço</label>
        <input
          type="text"
          id="endereco"
          name="endereco"
          placeholder="Digite seu Endereço..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>


      <div class="form-content">
        <label for="alergia">Alergia</label>
        <input
          type="text"
          id="alergia"
          name="alergia"
          placeholder="Digite sua alergia..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="descricao_alergia">Tipo de alergia</label>
        <input
          type="text"
          id="descricao_alergia"
          name="descricao_alergia"
          placeholder="Digite sua alergia..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>
      <input type="submit" name="submit" id="submit">

    </form>

  
  </div>
  <script>
  // Adicione a máscara de telefone usando o jQuery Mask Plugin
  $(document).ready(function(){
    $('#cpf').mask('000.000.000-00');
    $('#telefone').mask('(00) 00000-0000');
    $('#rg').mask('AA-00.000.000');
    $('#cep').mask('00000-00');
  });
</script>


  <script>
        function calcularIdade() {
            // Lógica para calcular a idade e adicionar um campo oculto ao formulário
            var dataNascimento = new Date(document.forms[0].elements['data_nascimento'].value);
            var hoje = new Date();
            var idade = hoje.getFullYear() - dataNascimento.getFullYear();

            // Ajuste se o aniversário ainda não ocorreu este ano
            if (hoje.getMonth() < dataNascimento.getMonth() || (hoje.getMonth() === dataNascimento.getMonth() && hoje.getDate() < dataNascimento.getDate())) {
                idade--;
            }

            // Adicionar um campo oculto com a idade ao formulário
            var inputIdade = document.createElement('input');
            inputIdade.type = 'hidden';
            inputIdade.name = 'idade';
            inputIdade.value = idade;

            document.forms[0].appendChild(inputIdade);

            return true;
        }
    </script>

  </html>
