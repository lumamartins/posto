<?php

session_start();
ini_set('default_charset', 'utf-8');
if(isset($_POST['submit']))
{

        include_once('../config.php');


    $cpf = $_POST['cpf'];
    $nome = $_POST['nome'];
    $nome_vacina = $_POST['nome_vacina'];
    $lote = $_POST['lote'];
    $data_vacinacao = $_POST['data_vacinacao'];
    
        // Colunas referentes a tabela vacina 
    $result = mysqli_query($conexao, "INSERT INTO vacina_paciente(cpf,nome,nome_vacina,lote,data_vacinacao) 
    VALUES('$cpf','$nome', '$nome_vacina','$lote','$data_vacinacao') ");
}

 // usuário logado (funcionário) no sistema
 $logado = $_SESSION['usuario'];
 if(!empty($_GET['search']))
 {
     $data = $_GET['search'];
     $sql = "SELECT * FROM pacientes WHERE id LIKE '%$data%' or nome LIKE '%$data%' or cpf LIKE '%$data%' ORDER BY id DESC";
 }
 else
 {
     $sql = "SELECT * FROM pacientes ORDER BY id DESC";
 }


?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro da Vacinação | Posto Fácil</title>
    <script src="script.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
  <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500&family=Open+Sans:wght@300;400;500;600&display=swap');
          * {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    font-family: 'Inter', sans-serif;
}

body {
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #A1C7E0;
    margin: 0;
     padding: 0;
}

.navbar{
    
    
    justify-content: space-between;
    align-items:center;
    background-color: white;
    padding: 15px 30px;
    position: absolute;
    margin: 0;
    padding: 0;
    top: 0;
    width:100%;
    height:110px;
    
   
}
.logo img{
    width: 110px;
    margin-left: 2%;
    
    background-size: cover;
   
    
}



.container {
    margin-left:10vh;
    width: 90%;
    height: 87vh;
    display: flex;
    border-radius: 4px;
    box-shadow: 5px 5px 10px black;
    margin-top: 2vh;
    
    
    
  
    
}



.form-image {
    width: 50%;
    display: flex;
    
    justify-content: center;
    align-items: center;
    background-color: #fff;
    padding: 1rem;
   
}
#smile{
    width: 45%;
    height: 87vh;
    object-fit: cover;
    position: absolute;
    opacity: 0.9;
    
}

.form-image img {
    width: 31rem;
}

.form {
    width: 50%;
    display: flex;
    flex-direction: column;
    background-color: #Fff;
    padding: 20px; 
    height: calc(133% - 0px); 
    overflow-y: auto; 
    height: 100%;
   
}

.form-header {
    margin-bottom: 3rem;
    display: flex;
    justify-content: space-between;
}

.login-button {
    
    display: flex;
    align-items: center;
    justify-content: end;
    
    
    
}

.login-button button {
    border: none;
    background-color: #A1C7E0;
    padding: 0.4rem 1rem;
    border-radius: 5px;
    cursor: pointer;
}

.login-button button:hover {
    background-color: #0099DD;
}

.login-button button a {
    text-decoration: none;
    font-weight: 500;
    color: #fff;
}

.form-header h1::after {
    content: '';
    display: block;
    width: 22.5rem;
    height: 0.3rem;
    background-color: #A1C7E0;
    margin: 0 auto;
    
    border-radius: 10px;
}

.input-group {
    
    flex-wrap: wrap;
    justify-content: space-evenly;
    padding: 1rem 0;
    gap: 20px;
    padding-top: 20px;
}

.input-box {
    display: flex;
    flex-direction: column;
    margin-bottom: 1.1rem;
    align-content: center;
}

.input-box input {
    margin: 0.6rem 0;
    padding: 0.8rem 1.2rem;
    border: none;
    border-radius: 10px;
    box-shadow: 1px 1px 6px #0000001c;
    font-size: 0.8rem;
}

.input-box input:hover {
    background-color: #eeeeee75;
}

.input-box input:focus-visible {
    outline: 1px solid #A1C7E0;
}

.input-box label,
.gender-title h6 {
    font-size: 0.75rem;
    font-weight: 600;
    color: #000000c0;
}

.input-box input::placeholder {
    color: #000000be;
}

.gender-group {
    display: flex;
    justify-content: space-between;
    margin-top: 0.62rem;
    padding: 0 .5rem;
}

.gender-input {
    display: flex;
    align-items: center;
}

.gender-input input {
    margin-right: 0.35rem;
}

.gender-input label {
    font-size: 0.81rem;
    font-weight: 600;
    color: #000000c0;
}

.continue-button button {
    width: 100%;
    border: none;
    background-color: #A1C7E0;
    padding: 0.62rem;
    border-radius: 5px;
    cursor: pointer;
    
}

.continue-button button:hover {
    background-color: #0099DD;
}

.continue-button button a {
    text-decoration: none;
    font-size: 0.93rem;
    font-weight: 500;
    color: #fff;
}

@media screen and (max-width: 1020px) {
    .form-image {
        display: none;
    }
    .container {
        width: 90%;
    }
    .form {
        width: 100%;
    }
}

@media screen and (max-width:768px) {
            .container {
                flex-direction: column;
                height: auto;
            }
            .form {
                width: 100%;
                height: auto;
               
            }
            .form-image {
                display: none;
            }
            #smile {
                display: none;
            }
        }

        @media screen and (max-width: 600px) {
            .input-box input {
                width: 100%;
            }
            .continue-button button {
                width: 100%;
            }
        }

    </style>
       

</head>
<body>
<nav class="navbar" >
    <div class="logo" >
<img src="/posto/imagens/POSTO FÁCIL.png"  width="444px" alt="">

    </div>

<div class="container">
        <div class="form-image">
            <img id="smile" src="/posto/imagens/reg_vac.jpg" alt="">
        </div>
        <div class="form">
            <form action="vac_cad_paciente.php" method="POST">
                <div class="form-header">
                    <div class="title">
                        <h1>Registro de Vacinação</h1>
                    </div>
                    <div class="login-button">
                        <button><a href="/posto/acoes/sistemas/sistema.php">Voltar</a></button>
                    </div>
                </div>

                <div class="input-group">
                    <div class="input-box">
                    <label for="cpf" class="labelInput">CPF do paciente cadastrado</label>
                    <input type="search" name="cpf" id="cpf" class="inputUser" class="btn btn-primary"required>
                    <button type="button" onclick="pesquisarPaciente()" class="btn btn-primary" fill="currentColor"   >
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
        </button>
                    </div>
                    
                    <div class="input-box">
                    <label for="nome" class="labelInput">Nome do paciente</label>
                    <input type="text" name="nome" id="nome" class="inputUser" readonly>
                    </div>

                    <div class="input-group">
                    <div class="input-box">
                    <label for="nome_vacina" class="labelInput">Vacina</label>
                    <input type="text" name="nome_vacina" id="nome_vacina" class="inputUser" required>
                    </div>
                  

                    <div class="input-group">
                    <div class="input-box">
                    <label for="lote" class="labelInput" >Lote</label>
                    <input type="text" name="lote" id="lote" class="inputUser" placeholder="XXXXXXX" required>
        
                    </div>
                    <div class="input-box">
                    <label for="data_vacinacao"><b>Data da Vacinação: </b></label>
                <input type="date" name="data_vacinacao" id="data_vacinacao" class="date" required>
                <br><br>
                       
                    


                <div class="continue-button">
                <button type="submit" name="submit" id="submit" class="inputUser" required>Enviar</button>
                
                </div>
                <script>
  // Adicione a máscara de telefone usando o jQuery Mask Plugin
  $(document).ready(function(){
    $('#cpf').mask('000.000.000-00');

  });
</script>

                <script>
        function pesquisarPaciente() {
            var cpf = document.getElementById('cpf').value;

            // Enviar requisição AJAX para o script PHP
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Atualizar o campo de nome com a resposta do servidor
                    document.getElementById('nome').value = xhr.responseText;
                }
            };

            xhr.open('GET', 'pesquisar_paciente.php?cpf=' + cpf, true);
            xhr.send();
        }
    </script>
            </form>
        </div>
    </div>

</body>
</html>

