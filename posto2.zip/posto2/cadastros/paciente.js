
    // Selecionar a div e o botão
    var divMostrarOcultar = document.getElementById("divMostrarOcultar");
    var mostrarOcultarBotao = document.getElementById("mostrarOcultarBotao");

    // Adicionar um ouvinte de evento ao botão
    mostrarOcultarBotao.addEventListener("click", function() {
        // Verificar o estado atual da div
        if (divMostrarOcultar.style.display === "none") {
            // Se estiver oculta, mostrar a div
            divMostrarOcultar.style.display = "block";
        } else {
            // Se estiver visível, ocultar a div
            divMostrarOcultar.style.display = "none";
        }
    });
