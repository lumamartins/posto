<?php
// pesquisar_paciente.php

// Conectar ao banco de dados (substitua os valores conforme necessário)
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'posto';

$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Obter o CPF da solicitação GET
$cpf = $_GET['cpf'];

// Consultar o banco de dados para encontrar o nome associado ao CPF
$sql = "SELECT nome FROM pacientes WHERE cpf = '$cpf'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Retornar o nome encontrado
    $row = $result->fetch_assoc();
    echo $row['nome'];
} else {
    // Se não houver correspondência, retornar uma mensagem indicando isso
    echo "Paciente não encontrado";
}

// Fechar a conexão
$conn->close();
?>