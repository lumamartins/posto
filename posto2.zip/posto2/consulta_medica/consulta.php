<?php


session_start();
ini_set('default_charset', 'utf-8');
if(isset($_POST['submit']))
{
 include_once('../config.php');
 $cpf = $_POST['cpf'];
 $nome = $_POST['nome'];   
 $funcionario = $_POST['funcionario'];   
 $dataconsulta = $_POST['dataconsulta'];   
 $hora = $_POST['hora'];   
 $motivo = $_POST['motivo'];   

 $result = mysqli_query($conexao, "INSERT INTO consulta(cpf,nome, funcionario,dataconsulta, hora, motivo) 
 VALUES('$cpf','$nome', '$funcionario','$dataconsulta', '$hora', '$motivo') ");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<title>Tela de Consulta Médica</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500&family=Open+Sans:wght@300;400;500;600&display=swap');
  body {
    background-image: url(/imagens/maos-da-medica-irreconhecivel-escrevendo-no-formulario-e-digitando-no-teclado-do-laptop.jpg);
    background-size: cover;
  background-position: center;
  font-family: 'Inter', sns-serif;

    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }

  .navbar{
    display: block;
    justify-content: space-between;
    align-items:center;
    background-color: white;
    position: absolute;
    padding: 15px 30px;
    margin: 0;
    padding: 0;
    top: 0;
    width:100%;
    
   
}
.logo img{
    width: 150px;
    margin-left: 5%
    
   
}
  
  .container {
    margin-top: 38%;
    max-width: 600px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 0 10px black;
    padding: 40px;
  }
  .form-group {
    margin-bottom: 20px;
  }
  .form-control {
    width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 16px;
  transition: border-color 0.3s;
  }

  .form-control:focus {
  border-color: #007bff;
}
  label {
    font-weight: bold;
 
  }

 
  
  button {
    padding: 12px 24px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;
  }
  button:hover {
  background-color: #0056b3;
}

 
  .appointments {
    margin-top: 30px;
    border-top: 1px solid #ccc;
    padding-top: 20px;
  }

  h1{
    font-weight: 500;
  }
  h2 {
    
    font-size: 24px;
    margin-bottom: 10px;
  }
  ul {
    list-style-type: none;
    padding: 0;
  }
  li {
    margin-bottom: 10px;
    font-size: 16px;
  }
</style>
</head>
<body>
<nav class="navbar">
<div class="logo" >
<img src="/posto/imagens/POSTO FÁCIL.png"  width="444px" alt="">
</nav>

    </div>
  <form action="consulta.php" method="POST">
  <div class="container">
    <h1 style="text-align: center; color: #007bff; margin-bottom: 3.5rem;">Consulta Médica</h1>
    <div class="form-group">
      <label  for="cpf">Digite o cpf do paciente cadastrado:</label><br>
      <input type="search" name="cpf" id="cpf" class="inputUser" class="btn btn-primary"required>
                    <button type="button" onclick="pesquisarPaciente()" class="btn btn-primary" id="button-pesquisar" >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
        </button>
    </div>
    
    <div class="form-group">
      <label  for="nome">Nome do Paciente:</label>
      <input type="text" id="nome" class="form-control" name="nome"readonly>
                  
    </div>

    <div class="form-group">
      <label  for="funcionario">Profissional:</label>
      <select id="funcionario" class="form-control" name="funcionario">
    <option value="" disabled selected>Selecione um profissional</option>
    <!-- Opções serão preenchidas dinamicamente usando jQuery -->
  </select>


    </div>
    <div class="form-group">
      <label for="dataconsulta">Data da Consulta:</label>
      <input type="date" id="dataconsulta" class="form-control" name="dataconsulta">
    </div>
    <div class="form-group">
      <label for="hora">Horário:</label>
      <input type="time" id="hora" class="form-control" name="hora">
    </div>
    <div class="form-group">
      <label for="motivo">Motivo da Consulta:</label>
      <textarea id="motivo" class="form-control" rows="4" name="motivo"></textarea>
    </div>
    <button type="submit" id="submit" name="submit" required>Agendar Consulta</button>
  </form>

  </div>
  <script>
  // Simulação de dados fictícios
  var dadosFuncionarios = [
    { nome: 'Dr. João', atendimento: 'sim' },
    { nome: 'Dra. Samanta', atendimento: 'sim' },
    { nome: 'Dra. Alice', atendimento: 'sim' },
    // Adicione mais funcionários conforme necessário
  ];

  // Preencher dinamicamente o campo de seleção
  $(document).ready(function(){
    var selectFuncionario = $('#funcionario');

    // Filtrar funcionários que selecionaram "sim" no atendimento
    var funcionariosSim = dadosFuncionarios.filter(function(funcionario) {
      return funcionario.atendimento === 'sim';
    });

    // Adicionar opções ao campo de seleção
    funcionariosSim.forEach(function(funcionario) {
      selectFuncionario.append('<option value="' + funcionario.nome + '">' + funcionario.nome + '</option>');
    });
  });
</script>

  <script>
        function pesquisarPaciente() {
            var cpf = document.getElementById('cpf').value;

            // Enviar requisição AJAX para o script PHP
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Atualizar o campo de nome com a resposta do servidor
                    document.getElementById('nome').value = xhr.responseText;
                }
            };

            xhr.open('GET', '/posto/cadastros/pesquisar_paciente.php?cpf=' + cpf, true);
            xhr.send();
        }
    </script>
</body>
</html>