CREATE DATABASE  IF NOT EXISTS `posto` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `posto`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: posto
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consulta`
--

DROP TABLE IF EXISTS `consulta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consulta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `dataconsulta` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta`
--

LOCK TABLES `consulta` WRITE;
/*!40000 ALTER TABLE `consulta` DISABLE KEYS */;
INSERT INTO `consulta` VALUES (1,'jon doe','2000-11-11','00:00:00','aeiou'),(2,'dfghjk','0000-00-00','00:00:00','n'),(3,'dfghjk','0000-00-00','00:00:00','n'),(4,'dfghjk','2222-11-11','00:00:00','n');
/*!40000 ALTER TABLE `consulta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexo` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_nascimento` date NOT NULL,
  `cidade` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `endereco` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cargos` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `atendimento` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionarios`
--

LOCK TABLES `funcionarios` WRITE;
/*!40000 ALTER TABLE `funcionarios` DISABLE KEYS */;
INSERT INTO `funcionarios` VALUES (3,'Alice','alice@gmail.com','11111111','feminino','2023-05-03','rg','gf','31268800','DBA','','alicinha23','11111'),(4,'Samanta','samanta@gmail.com','22222222','feminino','2023-05-01','bh','mg','33333333','Médica','','samantinha','1234');
/*!40000 ALTER TABLE `funcionarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicamento_cadastro`
--

DROP TABLE IF EXISTS `medicamento_cadastro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicamento_cadastro` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_comercial` varchar(200) NOT NULL,
  `nome_quimico` varchar(200) NOT NULL,
  `unidade` varchar(20) NOT NULL,
  `laboratorio` varchar(200) NOT NULL,
  `origem` varchar(100) NOT NULL,
  `forma_farmaceutica` varchar(300) NOT NULL,
  `tipo_uso` varchar(45) NOT NULL,
  `numero_registro` varchar(45) NOT NULL,
  `dt_validade` date NOT NULL,
  `dt_fabricacao` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicamento_cadastro`
--

LOCK TABLES `medicamento_cadastro` WRITE;
/*!40000 ALTER TABLE `medicamento_cadastro` DISABLE KEYS */;
INSERT INTO `medicamento_cadastro` VALUES (1,'nome','','0.00','nome','nome','sólido','via oral','nome','2023-10-20','2023-11-03'),(2,'Dipirona','','50.00','Butantan','Dentro do estado','sólido','via oral','24256383838383','2023-11-10','1998-04-10'),(3,'Dipirona','','5.00','Fiocruz','Dentro do estado','sólido','via oral','24256383838382','2027-05-11','2023-10-17'),(4,'Opioide','','20.00','Japão','Japão','sólido','via oral','ddwdtf3','2023-12-09','2023-10-30'),(5,'sssssssssss','','30mg','rffff','dddddd','semissólida','via sublingual','444','2023-11-23','2023-11-30'),(6,'Dipironaa','SLA','mg','SLA','AAA','líquido','via sublingual','3333','2023-11-29','2023-11-23');
/*!40000 ALTER TABLE `medicamento_cadastro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pacientes`
--

DROP TABLE IF EXISTS `pacientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pacientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `idade` varchar(40) NOT NULL,
  `rg` varchar(100) NOT NULL,
  `sexo` varchar(45) NOT NULL,
  `data_nascimento` date NOT NULL,
  `telefone` varchar(45) NOT NULL,
  `cidade` varchar(45) NOT NULL,
  `estado` varchar(45) NOT NULL,
  `cep` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `endereco` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alergia` varchar(100) NOT NULL,
  `descricao_alergia` varchar(400) NOT NULL,
  `cpf` varchar(21) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pacientes`
--

LOCK TABLES `pacientes` WRITE;
/*!40000 ALTER TABLE `pacientes` DISABLE KEYS */;
INSERT INTO `pacientes` VALUES (16,'Lucas Oliveira do Carmo','37','MG-13.459.234','M','1986-04-23','(65) 99910-7005','Belo Horizonte','MG','31832-345','Rua das Andorinhas, 90 - Serrano','Sem alergia ','Sem alergia','234.421.456-78'),(19,'Eduardo Silva Paoli','29','MG-14.422.938','F','1994-02-01','(31)93432-3237','Belo Horizonte','MG','33432-315','Rua da Inglaterra, 644 - Ipê Rosa','Sem alergia ','Sem alergia','137.039.646-87'),(20,'Thaís Silva Ferreira','27','MG-14.422.938','F','1996-01-12','(31)93432-3237','Belo Horizonte','MG','33432-315','Rua da Inglaterra, 644 - Ipê Rosa','Sem alergia ','Sem alergia','137.039.646-89');
/*!40000 ALTER TABLE `pacientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receita`
--

DROP TABLE IF EXISTS `receita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receita` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cpf` varchar(45) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `data_nascimento` date NOT NULL,
  `idade` varchar(45) NOT NULL,
  `funcionario` varchar(200) NOT NULL,
  `dt` date NOT NULL,
  `medicamento` varchar(100) NOT NULL,
  `dosagem` varchar(100) NOT NULL,
  `instrucoes` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receita`
--

LOCK TABLES `receita` WRITE;
/*!40000 ALTER TABLE `receita` DISABLE KEYS */;
INSERT INTO `receita` VALUES (1,'137.039.646-89','Thaís Silva Ferreira','0000-00-00','','Roberto','2023-11-01','Dipirona','20mg','Tomar 1x á noite');
/*!40000 ALTER TABLE `receita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vacina_cadastro`
--

DROP TABLE IF EXISTS `vacina_cadastro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vacina_cadastro` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_vacina` varchar(100) NOT NULL,
  `fabricante` varchar(100) NOT NULL,
  `quantidade` varchar(100) NOT NULL,
  `lote` varchar(100) NOT NULL,
  `origem` varchar(300) NOT NULL,
  `dt_recebimento` date NOT NULL,
  `dt_fabricacao` date NOT NULL,
  `dt_validade` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nome_vacina` (`nome_vacina`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacina_cadastro`
--

LOCK TABLES `vacina_cadastro` WRITE;
/*!40000 ALTER TABLE `vacina_cadastro` DISABLE KEYS */;
INSERT INTO `vacina_cadastro` VALUES (6,'Adulto Bivalente','Pfizer BioNTech','200','GF9670','SP - Fora do Estado','2023-11-05','2023-06-22','2024-05-22'),(7,'Astrazeneca','Fiocruz','100','223VCD066W','MG - Dentro do estado','2023-11-17','2023-08-08','2025-06-22');
/*!40000 ALTER TABLE `vacina_cadastro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vacina_paciente`
--

DROP TABLE IF EXISTS `vacina_paciente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vacina_paciente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_vacina` varchar(100) NOT NULL,
  `lote` varchar(40) DEFAULT NULL,
  `data_vacinacao` date NOT NULL,
  `cpf` char(11) NOT NULL,
  `nome` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacina_paciente`
--

LOCK TABLES `vacina_paciente` WRITE;
/*!40000 ALTER TABLE `vacina_paciente` DISABLE KEYS */;
INSERT INTO `vacina_paciente` VALUES (4,'Adulto Bivalente','GF9670','2023-11-22','234.421.456','Lucas Oliveira do Carmo');
/*!40000 ALTER TABLE `vacina_paciente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-23 19:17:20
