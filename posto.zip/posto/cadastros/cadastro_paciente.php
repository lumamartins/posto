<?php

session_start();
ini_set('default_charset', 'utf-8');
include_once('../config.php');


if(isset($_POST['submit']))
{ 
    $cpf = $_POST['cpf'];
    $rg = $_POST['rg'];
    $telefone = $_POST['telefone'];
    $sexo = $_POST['sexo'];
    $data_nasc = $_POST['data_nascimento'];
    $estado = $_POST['estado'];
    $cidade = $_POST['cidade'];
    $cep = $_POST['cep'];
    $rua = $_POST['rua'];
    $bairro = $_POST['bairro'];
    $numero = $_POST['numero'];

    
        // Colunas referentes a tabela pacientes 
    $result = mysqli_query($conexao, "INSERT INTO pacientes(nome,email,sexo,data_nascimento,telefone,cidade,estado,cep,rua,bairro,numero) 
    VALUES('$cpf','$rg','$sexo','$data_nasc','$telefone','$cidade','$estado','$cep','$rua','$bairro','$numero')");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

  

  <style>


*{
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: "Poppins", sans-serif;
  
}

body{
  
  background: #ccedff;
  width: 100%;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.container{
  background-color: #fafafa;
  border-radius: 14px;
  margin: 14px;
  max-width: 600px;
  width: 100%;
  box-sizing: 0 3px 5px rgba(0,0,0, 0.5);
  overflow: hidden;
}
.container2{
  background-color: #fafafa;
  border-radius: 14px;
  margin: 14px;
  max-width: 600px;
  width: 100%;
  box-sizing: 0 3px 5px rgba(0,0,0, 0.5);
  overflow: hidden;

}

.header{
  background: linear-gradient(120deg, #3acbf0 0%, #8bb0ff 100%);
  padding: 24px;
  text-align: center;
  color: #FFF;
}

.form{
  padding: 18px;
}

.form-content{
  margin-bottom: 8px;
  padding-bottom: 18px;
  position: relative;
}

.form-content label{
  display: inline-block;
  margin-bottom: 4px;
}

.form-content input{
  display: block;
  width: 100%;
  border-radius: 8px;
  padding: 8px;
  border: 2px solid #dfdfdf;
}

.form-content a{
  position: absolute;
  bottom: -8px;
  left: 0;
  visibility: hidden;
}

.form button{
  background-color: #00c3ff;
  color: #FFF;
  width: 100%;
  border-radius: 14px;
  padding: 10px;
  border: 0;
  font-size: 16px;
  cursor: pointer;
  margin-top: 14px;
}

.form-content.error input{
  border-color: #ff3b25;
}

.form-content.error a{
  color: #ff3b25;
  visibility: visible;
}
#sexo{
  display: flex;
  flex-direction: column;

}

form-content label {
  display: flex;
  align-items: center;
}

/* Estilize os inputs do tipo radio */
.form-content input[type="radio"] {
  appearance: none; 
  -webkit-appearance: none;
  -moz-appearance: none;
  width: 16px; 
  height: 16px; 
  border: 2px solid #333; 
  border-radius: 50%; 
  background-color: white; 
  margin-right: 5px; 
  margin: 3px;
}


.form-content input[type="radio"]:checked {
  background-color: #333; 
}


.form-content {
  margin-bottom: 10px; 
}












  </style>

  <title>cadastro paciente</title>
</head>
<body>

  <div class="container">
    <section class="header">
      <h2>Cadastro do paciente</h2>
    </section>

    <form id="form" class="form" method="POST">
      
      <div class="form-content">
        <label for="cpf">CPF</label>
        <input
          type="CPF"
          id="cpf"
          name="cpf"
          placeholder="Digite seu CPF..."
          
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="rg">RG</label>
        <input
          type="text"
          id="rg"
          name="rg"
          placeholder="Digite seu RG..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="telefone">Telefone</label>
        <input
          type="number"
          id="telefone"
          name="telefone"
          placeholder="Digite seu telefone"
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div  id="sexo"class="form-content">
        <label  for="Sexo"><span>Sexo:</span><br><input  type="radio" id="sexo" name="sexo" value="M"  /> Masculino
          <input  type="radio" id="sexo" name="sexo" value="F" /> Feminino</label>
          <input  type="radio" id="sexo"  name="sexo" value="O" /> Outro</label>
        </label>
        
        
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="datanasc">Data de Nascimento</label>
        <input
          type="date"
          id="data_nascimento"
          name="data_nascimento"
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="cidade">Cidade</label>
        <input
          type="text"
          id="cidade"
          name="cidade"
          placeholder="Digite sua cidade"
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="estado">Estado</label>
        <select name="estado" id="estado">
          <option value="">--</option>
          <option value="PR">SP</option>
          <option value="PR">RJ</option>
          <option value="PR">MG</option>
          <option value="PR">PR</option>
          <option value="PR">AC</option>
          <option value="PR">AL</option>
          <option value="PR">AP</option>
          <option value="PR">AM</option>
          <option value="PR">BA</option>
          <option value="PR">CE</option>
      </select>
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="cep">CEP</label>
        <input
          type="number"
          id="cep"
          name="cep"
          placeholder="Digite seu cep..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="rua">Rua</label>
        <input
          type="text"
          id="rua"
          name="rua"
          placeholder="Digite sua rua..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="bairro">Bairro</label>
        <input
          type="text"
          id="bairro"
          name="bairro"
          placeholder="Digite seu bairro..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="numero">Número</label>
        <input
          type="number"
          id="numero"
          name="numero"
          placeholder="Digite seu número..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="alergia">Alergia</label>
        <input
          type="text"
          id="alergia"
          name="alergia"
          placeholder="Digite sua alergia..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>

      <div class="form-content">
        <label for="tipodealergia">Tipo de alergia</label>
        <input
          type="text"
          id="tipodealergia"
          name="tipodealergia"
          placeholder="Digite sua alergia..."
        />
        <a>Aqui vai a mensagem de erro....</a>
      </div>
      <input type="submit" name="submit" id="submit">

    </form>
  </div>
  

  
