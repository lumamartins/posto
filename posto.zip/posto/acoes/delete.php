<?php
// Pagina para deletar as informações do usuario paciente no sistema
    if(!empty($_GET['id']))
    {
        include_once('./config.php');

        $id = $_GET['id'];

        $sqlSelect = "SELECT *  FROM pacientes WHERE id=$id";

        $result = $conexao->query($sqlSelect);

        if($result->num_rows > 0)
        {
            $sqlDelete = "DELETE FROM pacientes WHERE id=$id";
            $resultDelete = $conexao->query($sqlDelete);
        }
    }
    header('Location: sistema_paciente.php');
   
?>