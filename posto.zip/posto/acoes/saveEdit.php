<?php
    include_once('../config.php');
    if(isset($_POST['update']))
    {
    $id = $_POST['id'];
    $cpf = $_POST['cpf'];
    $nome = $_POST['nome'];
    $rg = $_POST['rg'];
    $sexo = $_POST['sexo'];
    $telefone = $_POST['telefone'];
    $data_nascimento = $_POST['data_nascimento'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $cep = $_POST['cep'];
    $rua = $_POST['rua'];
    $bairro = $_POST['bairro'];
    $numero = $_POST['numero'];
    $alergia = $_POST['alergia'];
    $descricao_alergia = $_POST['descricao_alergia'];
        
        $sqlUpdate = mysqli_query($conexao, "UPDATE pacientes 
        SET cpf='$cpf',nome='$nome',rg='$rg',sexo='$sexo',telefone='$telefone',
        data_nascimento='$data_nascimento',cidade='$cidade',estado='$estado',
        cep='$cep', rua='$rua', bairro='$bairro', numero='$numero', 
        alergia='$alergia', descricao_alergia='$descricao_alergia'
        WHERE id= '$id'");
        $result = $conexao->query($sqlUpdate);
    }
    header('Location: /posto/acoes/sistemas/sistema_paciente.php');
?>
