<?php
// Salvamento da edição do registro de vacinação

    include_once('../config.php');
    if(isset($_POST['update']))
    {
        $id = $_POST['id'];
        $nome = $_POST['nome'];   
        $dataconsulta = $_POST['dataconsulta'];   
        $hora = $_POST['hora'];   
        $motivo = $_POST['motivo'];   
        
        $sqlUpdate = mysqli_query($conexao, "UPDATE consulta
        SET nome='$nome',dataconsulta='$dataconsulta',hora='$hora',motivo='$motivo'
        WHERE id= '$id'");
        $result = $conexao->query($sqlUpdate);
    }
    header('Location: /posto/consulta_medica/consulta_view.php');
?>
