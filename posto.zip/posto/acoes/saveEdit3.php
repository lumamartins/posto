<?php
    include_once('../config.php');
    if(isset($_POST['update']))
    {
        $id = $_POST['id'];
        $nome_comercial = $_POST['nome_comercial'];
        $nome_quimico= $_POST['nome_quimico'];
        $unidade= $_POST['unidade'];
        $laboratorio = $_POST['laboratorio'];
        $origem = $_POST['origem'];
        $forma_farmaceutica = $_POST['forma_farmaceutica'];
        $tipo_uso = $_POST['tipo_uso'];
        $numero_registro = $_POST['numero_registro'];
        $dt_validade = $_POST['dt_validade'];
        $dt_fabricacao = $_POST['dt_fabricacao'];
        
        $sqlUpdate = mysqli_query($conexao, "UPDATE medicamento_cadastro 
        SET nome_comercial='$nome_comercial',nome_quimico='$nome_quimico',unidade='$unidade',laboratorio='$laboratorio',origem='$origem',
        forma_farmaceutica='$forma_farmaceutica',tipo_uso='$tipo_uso',numero_registro='$numero_registro',
        dt_validade='$dt_validade', dt_fabricacao='$dt_fabricacao'
        WHERE id= '$id'");
        $result = $conexao->query($sqlUpdate);
    }
    header('Location: /posto/estoque/medicamento_estoque.php');
?>
