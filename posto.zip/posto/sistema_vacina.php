<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Posto Fácil - Vacinas</title>
    <style> body{
        font-family: Arial, Helvetica, sans-serif;
    }

    .titulo{ display: flex;
  justify-content: center;
  align-items: center;

  }
        .container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  height: 100vh; /* Defina a altura total da tela ou valor desejado */
}

.image-wrapper {
  text-align: center;
  margin-bottom: 10px; /* Espaçamento entre as imagens */
}

.image-wrapper img {
  width: 350px; /* Defina a largura desejada para as imagens */
}

.image-wrapper h3 {
  margin-top: 1px; /* Espaçamento entre a imagem e o título */
}</style>
</head>
<body>
    <main>
    <div class="titulo">
            <h1> Vacinas </h1></div>
    <div class="container">
  <div class="image-wrapper">
    <a href="vacina_cadastro.php"><img src="imagens_sistema/vac_cad_entrada.png" alt="Imagem 1" ></a>
    <h3>Cadastro de Vacinas</h3>
  </div>
  <div class="image-wrapper">
  <a href="vacina_estoque.php"><img src="imagens_sistema/vacina_estoque.png" alt="Imagem 2"></a>
    <h3>Estoque de Vacinas</h3>
  </div>
</div>
    
    </main>
</body>
</html>