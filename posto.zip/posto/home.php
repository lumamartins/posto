<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>

      
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-image: url("back_sistema.jpg");
            background-size:cover;
            text-align: center;
            color: white;
        }
        .icons{
            text-align: center;
        }
        
        
       
    </style>
</head>
<body>
   
   

        <div class="icons">
      <img src="postofacil_logo.png">
      <br>
        <a href="cadastro_funcionario.php"><img src="imagens_home/cad_func.png"></a>
        <a href="cadastro_paciente.php"><img src="imagens_home/cad_pac.png"></a>
        <a href="login.php"><img src="imagens_home/icon_login.png"></a>
    </div>
    
</body>
</html>