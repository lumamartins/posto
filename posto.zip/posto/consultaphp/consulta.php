<?php
session_start();
ini_set('default_charset', 'utf-8');
if(isset($_POST['submit']))
{
 include_once('../config.php');

 $name = $_POST['name'];   
 $date = $_POST['date'];   
 $time = $_POST['time'];   
 $reason = $_POST['reason'];   

 $result = mysqli_query($conexao, "INSERT INTO consulta(nome, dataconsulta, hora, motivo) 
 VALUES('$name', '$date', '$time', '$reason') ");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Tela de Consulta Médica</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500&family=Open+Sans:wght@300;400;500;600&display=swap');
  body {
    background-image: url(/imagens/maos-da-medica-irreconhecivel-escrevendo-no-formulario-e-digitando-no-teclado-do-laptop.jpg);
    background-size: cover;
  background-position: center;
  font-family: 'Inter', sns-serif;
    background-color: #f7f7f7;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  
  .container {
    
    max-width: 600px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 0 10px black;
    padding: 40px;
  }
  .form-group {
    margin-bottom: 20px;
  }
  .form-control {
    width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 16px;
  transition: border-color 0.3s;
  }

  .form-control:focus {
  border-color: #007bff;
}
  label {
    font-weight: bold;
 
  }

  
  
  button {
    padding: 12px 24px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;
  }
  button:hover {
  background-color: #0056b3;
}
  .appointments {
    margin-top: 30px;
    border-top: 1px solid #ccc;
    padding-top: 20px;
  }

  h1{
    font-weight: 500;
  }
  h2 {
    
    font-size: 24px;
    margin-bottom: 10px;
  }
  ul {
    list-style-type: none;
    padding: 0;
  }
  li {
    margin-bottom: 10px;
    font-size: 16px;
  }
</style>
</head>
<body>
  <div class="container">
    <h1 style="text-align: center; color: #007bff; margin-bottom: 3.5rem;">Consulta Médica</h1>
    <div class="form-group">
      <label  for="name">Nome do Paciente:</label>
      <input type="text" id="name" class="form-control">
    </div>
    <div class="form-group">
      <label for="date">Data da Consulta:</label>
      <input type="date" id="date" class="form-control">
    </div>
    <div class="form-group">
      <label for="time">Horário:</label>
      <input type="time" id="time" class="form-control">
    </div>
    <div class="form-group">
      <label for="reason">Motivo da Consulta:</label>
      <textarea id="reason" class="form-control" rows="4"></textarea>
    </div>
    <button onclick="agendarConsulta()">Agendar Consulta</button>

    <div class="appointments">
      <h2>Consultas Agendadas:</h2>
      <ul id="appointmentList"></ul>
    </div>
  </div>

  <div class="m-5">
        <table class="table text-white table-bg">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">nome</th>
                    <th scope="col">data</th>
                    <th scope="col">hora</th>
                    <th scope="col">motivo</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    while($user_data = mysqli_fetch_assoc($result)) {
                        
                        echo "<td>".$user_data['name']."</td>";
                        echo "<td>".$user_data['date']."</td>";
                        echo "<td>".$user_data['time']."</td>";
                        echo "<td>".$user_data['reason']."</td>";
                        echo "</tr>";
                    }
                    ?>
            </tbody>
        </table>
    </div>
</body>
</html>