<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
     
    body{
        font-family: Arial, Helvetica, sans-serif;
    }

        .container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  height: 100vh; /* Defina a altura total da tela ou valor desejado */
}

.image-wrapper {
  text-align: center;
  margin-bottom: 20px; /* Espaçamento entre as imagens */
}

.image-wrapper img {
  width: 200px; /* Defina a largura desejada para as imagens */
}

.image-wrapper h3 {
  margin-top: 1px; /* Espaçamento entre a imagem e o título */
}
    </style>
</head>
<body>
    <header>
         
    </header>
    <main>
    <div class="container">
  <div class="image-wrapper">
    <a href="sistema_paciente.php"><img src="imagens_sistema/paciente_entrada.png" alt="Imagem 1" ></a>
    <h3>Área dos Pacientes</h3>
  </div>
  <div class="image-wrapper">
  <a href="sistema_vacina.php"><img src="imagens_sistema/vacina_entrada.png" alt="Imagem 2"></a>
    <h3>Área de Vacinas</h3>
  </div>
  <div class="image-wrapper">
  <a href="sistema_medicamento.php"><img src="imagens_sistema/medicamento_entrada.png" alt="Imagem 3"></a>
    <h3>Área de Medicamentos</h3>
  </div>
</div>
    </main>
</body>
</html>