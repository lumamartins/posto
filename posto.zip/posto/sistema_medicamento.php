<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Posto Fácil - Medicamentos</title>
    <style>
       body{
        font-family: Arial, Helvetica, sans-serif;
    }

        .container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  height: 100vh; /* Defina a altura total da tela ou valor desejado */
}

.image-wrapper {
  text-align: center;
  margin-bottom: 20px; /* Espaçamento entre as imagens */
}

.image-wrapper img {
  width: 400px; /* Defina a largura desejada para as imagens */
}

.image-wrapper h3 {
  margin-top: 1px; /* Espaçamento entre a imagem e o título */
}
  .titulo{ display: flex;
  justify-content: center;
  align-items: center;

  }
    </style>
</head>
<body>
    <div class="titulo">
            <h1> Medicamentos </h1></div>
         
            <div class="container">
  <div class="image-wrapper">
    <img src="" alt="Imagem 1">
    <h3>Cadastro de Medicamentos</h3>
  </div>
  <div class="image-wrapper">
    <img src="imagem2.jpg" alt="Imagem 2">
    <h3>Estoque de Medicamentos</h3>
  </div>
</div>
</body>
</html>